import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Screen } from "@/components/shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { addWeight, getProfile, listWeight } from "@/lib/server/fitness";
import { keys } from "@/lib/query";
import { formatKg, fromDisplayWeight, toDisplayWeight } from "@/lib/format";
import { ageFromBirthYear, bmi, bmiCategory, estimateBodyFatPct, normalizeSex } from "@/lib/body-composition";
import { Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export const Route = createFileRoute("/weight")({ component: WeightPage });

function WeightPage() {
  const qc = useQueryClient();
  const { data: profile } = useQuery({ queryKey: keys.profile, queryFn: () => getProfile() });
  const { data: entries } = useQuery({ queryKey: keys.weight, queryFn: () => listWeight() });
  const unit = profile?.unitPref ?? "kg";
  const [val, setVal] = useState("");

  const age = ageFromBirthYear(profile?.birthYear ?? null);
  const sex = normalizeSex(profile?.sex ?? null);

  const add = useMutation({
    mutationFn: () => {
      const valueKg = fromDisplayWeight(Number(val), unit);
      // No BLE bioimpedance reading for a manual entry — fall back to the
      // classic anthropometric estimate when we have enough profile data,
      // clearly flagged as estimated (never presented as measured).
      const estimated = estimateBodyFatPct({ weightKg: valueKg, heightCm: profile?.heightCm, age, sex });
      return addWeight({
        data: {
          valueKg,
          bodyFatPct: estimated,
          isEstimated: estimated != null,
        },
      });
    },
    onSuccess: () => {
      setVal("");
      void qc.invalidateQueries({ queryKey: keys.weight });
      void qc.invalidateQueries({ queryKey: keys.dashboard });
    },
  });

  const chart = useMemo(() => {
    const byDay = new Map<string, number>();
    for (const e of entries ?? []) byDay.set(e.date, e.valueKg);
    return [...byDay.entries()].map(([date, kg]) => ({ date, kg: toDisplayWeight(kg, unit) }));
  }, [entries, unit]);

  const latest = entries?.[entries.length - 1];
  const ma = movingAvg(chart.map((c) => c.kg), 7);
  const latestBmi = latest ? bmi(latest.valueKg, profile?.heightCm) : null;

  return (
    <Screen title="Weight">
      <Card className="mb-4">
        <p className="text-[13px] text-muted">Latest</p>
        <p className="font-display text-[40px] font-bold tabular">
          {latest ? formatKg(latest.valueKg, unit) : "—"}
        </p>
        {profile?.goalWeightKg ? (
          <p className="text-[13px] text-muted">Goal {formatKg(profile.goalWeightKg, unit)}</p>
        ) : null}
      </Card>
      {latest && (latestBmi != null || latest.bodyFatPct != null || latest.musclePct != null || latest.waterPct != null) ? (
        <Card className="mb-4 grid grid-cols-2 gap-y-3">
          {latestBmi != null ? <Metric label="BMI" value={latestBmi.toFixed(1)} sub={bmiCategory(latestBmi)} /> : null}
          {latest.bodyFatPct != null ? (
            <Metric
              label="Body fat"
              value={`${latest.bodyFatPct.toFixed(1)}%`}
              sub={latest.isEstimated ? "Estimated" : "Measured"}
            />
          ) : null}
          {latest.musclePct != null ? <Metric label="Muscle" value={`${latest.musclePct.toFixed(1)}%`} /> : null}
          {latest.waterPct != null ? <Metric label="Water" value={`${latest.waterPct.toFixed(1)}%`} /> : null}
          {latest.muscleMassKg != null ? <Metric label="Muscle mass" value={`${latest.muscleMassKg.toFixed(1)} kg`} /> : null}
          {latest.fatFreeMassKg != null ? <Metric label="Fat-free mass" value={`${latest.fatFreeMassKg.toFixed(1)} kg`} /> : null}
          {latest.bmrKcal != null ? <Metric label="BMR" value={`${Math.round(latest.bmrKcal)} kcal`} /> : null}
        </Card>
      ) : null}
      <Card className="mb-4 h-52">
        {chart.length > 1 ? (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chart.map((c, i) => ({ ...c, ma: ma[i] }))}>
              <XAxis dataKey="date" hide />
              <YAxis domain={["auto", "auto"]} hide />
              <Tooltip />
              {profile?.goalWeightKg ? (
                <ReferenceLine y={toDisplayWeight(profile.goalWeightKg, unit)} stroke="var(--app-muted)" />
              ) : null}
              <Line type="monotone" dataKey="kg" stroke="var(--app-accent)" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="ma" stroke="var(--color-ring-ex)" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <p className="grid h-full place-items-center text-muted">Log a few days to see the trend</p>
        )}
      </Card>
      <div className="mb-3 flex gap-2">
        <Input
          inputMode="decimal"
          value={val}
          onChange={(e) => setVal(e.target.value)}
          placeholder={`Weight (${unit})`}
        />
        <Button className="shrink-0" disabled={!val || add.isPending} onClick={() => add.mutate()}>
          Log
        </Button>
      </div>
      {!profile?.heightCm || age == null ? (
        <p className="mb-3 text-[12px] leading-relaxed text-muted">
          Add your height and birth year in Settings to get an estimated body fat % with each manual entry.
        </p>
      ) : null}
      <Link to="/scale" className="mb-4 block text-[15px] font-semibold text-accent">
        Connect a Bluetooth scale for full body composition
      </Link>
      <div className="space-y-2">
        {[...(entries ?? [])].reverse().slice(0, 20).map((e) => (
          <Card key={e.id} className="py-3">
            <div className="flex justify-between">
              <span className="text-[13px] text-muted">
                {e.date} · {e.source}
              </span>
              <span className="tabular font-semibold">{formatKg(e.valueKg, unit)}</span>
            </div>
            {e.bodyFatPct != null || e.musclePct != null || e.waterPct != null ? (
              <p className="mt-1 text-[12px] text-muted">
                {e.bodyFatPct != null ? `Fat ${e.bodyFatPct.toFixed(1)}%${e.isEstimated ? " (est.)" : ""}` : null}
                {e.musclePct != null ? ` · Muscle ${e.musclePct.toFixed(1)}%` : null}
                {e.waterPct != null ? ` · Water ${e.waterPct.toFixed(1)}%` : null}
              </p>
            ) : null}
          </Card>
        ))}
      </div>
    </Screen>
  );
}

function Metric({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div>
      <p className="text-[12px] text-muted">{label}</p>
      <p className="tabular text-[17px] font-semibold">{value}</p>
      {sub ? <p className="text-[11px] text-muted">{sub}</p> : null}
    </div>
  );
}

function movingAvg(values: number[], n: number) {
  return values.map((_, i) => {
    const slice = values.slice(Math.max(0, i - n + 1), i + 1);
    return slice.reduce((a, b) => a + b, 0) / slice.length;
  });
}
