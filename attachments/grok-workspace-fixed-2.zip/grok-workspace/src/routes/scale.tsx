import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { Screen } from "@/components/shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { addWeight, getProfile, saveBleDevice } from "@/lib/server/fitness";
import { keys } from "@/lib/query";
import { toast } from "sonner";
import { parseOkokAdvertisement, type OkokReading } from "@/lib/ble/okok";
import {
  isLeScanSupported,
  isWebBluetoothSupported,
  startAdvertisementScan,
  type BluetoothAdvertisingEvent,
} from "@/lib/ble/scale-broadcast";

export const Route = createFileRoute("/scale")({ component: ScalePage });

// Standard Bluetooth SIG GATT services — these are the two profiles that
// scales which speak plain Bluetooth LE (rather than a vendor's proprietary
// protocol) expose, connect-and-read style. Below this, `BroadcastScan`
// handles the *other* common case: scales (OKOK/Chipsea/"Nameless" clones,
// same family openScale's "OKOK C0" / "OKOK 1.1" drivers cover) that never
// expose a GATT service at all and instead just broadcast the reading in
// their advertisement packet, so nothing here ever "connects" to them.
const WEIGHT_SERVICE = 0x181d;
const WEIGHT_CHAR = 0x2a9d;
const BODY_COMP_SERVICE = 0x181b;
const BODY_COMP_CHAR = 0x2a9c;

type Composition = {
  valueKg: number | null;
  bodyFatPct: number | null;
  musclePct: number | null;
  muscleMassKg: number | null;
  fatFreeMassKg: number | null;
  waterPct: number | null;
  bmrKcal: number | null;
  impedanceOhm: number | null;
};

const EMPTY: Composition = {
  valueKg: null,
  bodyFatPct: null,
  musclePct: null,
  muscleMassKg: null,
  fatFreeMassKg: null,
  waterPct: null,
  bmrKcal: null,
  impedanceOhm: null,
};

function ScalePage() {
  const [status, setStatus] = useState("Idle");
  const [reading, setReading] = useState<Composition>(EMPTY);
  const qc = useQueryClient();
  const { data: profile } = useQuery({ queryKey: keys.profile, queryFn: () => getProfile() });

  const save = useMutation({
    mutationFn: () =>
      addWeight({
        data: {
          valueKg: reading.valueKg ?? 0,
          source: "ble",
          deviceName: "BLE scale",
          bodyFatPct: reading.bodyFatPct,
          musclePct: reading.musclePct,
          muscleMassKg: reading.muscleMassKg,
          fatFreeMassKg: reading.fatFreeMassKg,
          waterPct: reading.waterPct,
          bmrKcal: reading.bmrKcal,
          impedanceOhm: reading.impedanceOhm,
        },
      }),
    onSuccess: () => {
      toast.success("Weight saved");
      void qc.invalidateQueries({ queryKey: keys.weight });
      void qc.invalidateQueries({ queryKey: keys.dashboard });
      setReading(EMPTY);
      setStatus("Idle");
    },
  });
  const remember = useMutation({
    mutationFn: (name: string) => saveBleDevice({ data: { name, kind: "scale" } }),
  });

  async function connect() {
    const bt = (navigator as Navigator & { bluetooth?: Bluetooth }).bluetooth;
    if (!bt) {
      toast.error("Web Bluetooth is not available in this browser. Log weight manually.");
      return;
    }
    try {
      setStatus("Scanning…");
      setReading(EMPTY);
      const device = await bt.requestDevice({
        filters: [{ services: [WEIGHT_SERVICE] }, { services: [BODY_COMP_SERVICE] }],
        optionalServices: [WEIGHT_SERVICE, BODY_COMP_SERVICE],
      });
      remember.mutate(device.name || "Scale");
      setStatus(`Connecting to ${device.name ?? "scale"}…`);
      const server = await device.gatt?.connect();
      if (!server) throw new Error("Could not open a GATT connection");

      let subscribed = false;

      // Weight Scale service — gives a plain weight reading.
      try {
        const service = await server.getPrimaryService(WEIGHT_SERVICE);
        const char = await service.getCharacteristic(WEIGHT_CHAR);
        await char.startNotifications();
        char.addEventListener("characteristicvaluechanged", (ev) => {
          const target = ev.target as BluetoothRemoteGATTCharacteristic;
          const kg = parseWeight(target.value);
          if (kg != null) {
            setReading((c) => ({ ...c, valueKg: kg }));
            setStatus("Reading weight…");
          }
        });
        subscribed = true;
      } catch {
        // This device doesn't expose the standard Weight Scale service.
      }

      // Body Composition service — bioimpedance metrics, when the scale has
      // the hardware for it (foot/hand electrodes) and exposes it over BLE.
      try {
        const service = await server.getPrimaryService(BODY_COMP_SERVICE);
        const char = await service.getCharacteristic(BODY_COMP_CHAR);
        await char.startNotifications();
        char.addEventListener("characteristicvaluechanged", (ev) => {
          const target = ev.target as BluetoothRemoteGATTCharacteristic;
          const parsed = parseBodyComposition(target.value);
          if (parsed) {
            setReading((c) => ({ ...c, ...parsed }));
            setStatus("Reading body composition…");
          }
        });
        subscribed = true;
      } catch {
        // This device doesn't expose the standard Body Composition service.
      }

      if (!subscribed) {
        setStatus("Connected, but no supported service was found");
        toast.message(
          "This scale doesn't speak a standard Bluetooth weight profile. Many consumer scales use a " +
            "proprietary protocol — log manually from the Weight screen instead.",
        );
        return;
      }
      setStatus("Connected — step on the scale");
    } catch (e) {
      setStatus("Cancelled or unsupported device");
      toast.message(e instanceof Error ? e.message : "Could not connect. Many consumer scales use proprietary protocols.");
    }
  }

  const unit = profile?.unitPref ?? "kg";
  const rows: [string, string | null][] = [
    ["Weight", reading.valueKg != null ? `${toDisplay(reading.valueKg, unit).toFixed(1)} ${unit}` : null],
    ["Body fat", reading.bodyFatPct != null ? `${reading.bodyFatPct.toFixed(1)}%` : null],
    ["Muscle", reading.musclePct != null ? `${reading.musclePct.toFixed(1)}%` : null],
    ["Muscle mass", reading.muscleMassKg != null ? `${reading.muscleMassKg.toFixed(1)} kg` : null],
    ["Water", reading.waterPct != null ? `${reading.waterPct.toFixed(1)}%` : null],
    ["Fat-free mass", reading.fatFreeMassKg != null ? `${reading.fatFreeMassKg.toFixed(1)} kg` : null],
    ["BMR", reading.bmrKcal != null ? `${Math.round(reading.bmrKcal)} kcal` : null],
    ["Impedance", reading.impedanceOhm != null ? `${Math.round(reading.impedanceOhm)} Ω` : null],
  ];
  const hasAnyReading = rows.some(([, v]) => v != null);

  return (
    <Screen title="Scale">
      <Card className="mb-4">
        <p className="text-[13px] text-muted">Live reading</p>
        <p className="font-display text-[40px] font-bold tabular">
          {reading.valueKg != null ? `${toDisplay(reading.valueKg, unit).toFixed(1)} ${unit}` : "—"}
        </p>
        <p className="text-[13px] text-muted">{status}</p>
      </Card>
      <Button className="mb-3 w-full" onClick={() => void connect()}>
        Scan for scale
      </Button>
      {hasAnyReading ? (
        <Card className="mb-4 space-y-1">
          {rows
            .filter(([, v]) => v != null)
            .map(([k, v]) => (
              <div key={k} className="flex justify-between text-[15px]">
                <span className="text-muted">{k}</span>
                <span className="tabular font-semibold">{v}</span>
              </div>
            ))}
        </Card>
      ) : null}
      {reading.valueKg != null ? (
        <Button className="mb-4 w-full" variant="secondary" onClick={() => save.mutate()} disabled={save.isPending}>
          Save reading
        </Button>
      ) : null}
      <p className="mb-6 text-[13px] leading-relaxed text-muted">
        The button above works with scales that expose the standard Weight Scale or Body Composition
        Bluetooth services. Many cheap "Nameless"/OKOK-style scales don't — see below instead.
      </p>

      <BroadcastScan
        unit={unit}
        onReading={(r) => {
          setReading((c) => ({ ...c, valueKg: r.valueKg }));
          setStatus(`${r.valueKg.toFixed(2)} kg from broadcast`);
        }}
        onRemember={(name) => remember.mutate(name)}
      />
    </Screen>
  );
}

type FoundDevice = {
  id: string;
  name: string;
  rssi: number | null;
  reading: OkokReading | null;
  lastSeen: number;
};

/**
 * Scales like the ones openScale labels "OKOK C0" / "OKOK 1.1" never expose
 * a GATT service — they just repeat their current reading inside their BLE
 * advertisement packet. There's no `connect()` step: this passively listens
 * for those broadcasts and decodes any that match (see lib/ble/okok.ts).
 */
function BroadcastScan({
  unit,
  onReading,
  onRemember,
}: {
  unit: "kg" | "lb";
  onReading: (r: OkokReading) => void;
  onRemember: (name: string) => void;
}) {
  const [scanning, setScanning] = useState(false);
  const [devices, setDevices] = useState<Record<string, FoundDevice>>({});
  const [error, setError] = useState<string | null>(null);
  const stopRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    return () => stopRef.current?.();
  }, []);

  async function start() {
    setError(null);
    setDevices({});
    try {
      const stop = await startAdvertisementScan((ev: BluetoothAdvertisingEvent) => {
        const okok = parseOkokAdvertisement(ev.manufacturerData);
        setDevices((prev) => ({
          ...prev,
          [ev.device.id]: {
            id: ev.device.id,
            name: ev.device.name || "Nameless",
            rssi: ev.rssi ?? null,
            reading: okok ?? prev[ev.device.id]?.reading ?? null,
            lastSeen: Date.now(),
          },
        }));
      });
      stopRef.current = stop;
      setScanning(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not start scanning.");
    }
  }

  function stop() {
    stopRef.current?.();
    stopRef.current = null;
    setScanning(false);
  }

  const list = Object.values(devices).sort((a, b) => b.lastSeen - a.lastSeen);
  const supported = isWebBluetoothSupported() && isLeScanSupported();

  return (
    <div>
      <p className="mb-2 text-[13px] font-semibold text-muted">Broadcast scan (OKOK / no-GATT scales)</p>
      <Button className="mb-3 w-full" variant={scanning ? "secondary" : "primary"} onClick={() => (scanning ? stop() : void start())}>
        {scanning ? "Stop scan" : "Scan for broadcasts"}
      </Button>
      {error ? <p className="mb-3 text-[13px] leading-relaxed text-red-500">{error}</p> : null}
      {!supported && !error ? (
        <p className="mb-4 text-[12px] leading-relaxed text-muted">
          This needs Chrome on Android with an experimental flag turned on: open chrome://flags, enable
          "Experimental Web Platform features", and restart the browser. It isn't available in Safari or
          Firefox.
        </p>
      ) : null}
      {list.length > 0 ? (
        <div className="mb-4 space-y-2">
          <p className="text-[13px] text-muted">Found devices:</p>
          {list.map((d) => (
            <Card key={d.id} className="flex items-center justify-between py-3">
              <div>
                <p className="font-semibold">{d.name}</p>
                <p className="text-[12px] text-muted">
                  {d.rssi != null ? `${d.rssi} dBm` : "—"}
                  {d.reading ? ` · ${toDisplay(d.reading.valueKg, unit).toFixed(2)} ${unit}` : " · no reading yet"}
                </p>
              </div>
              {d.reading ? (
                <Button
                  onClick={() => {
                    onReading(d.reading!);
                    onRemember(d.name);
                  }}
                >
                  Use
                </Button>
              ) : null}
            </Card>
          ))}
        </div>
      ) : null}
      <p className="text-[13px] leading-relaxed text-muted">
        Step on the scale so it's actively broadcasting, then tap "Use" once a weight shows up next to it.
        These scales only ever send the live number on their own display — no history, no body composition.
      </p>
    </div>
  );
}

function toDisplay(kg: number, unit: "kg" | "lb"): number {
  return unit === "lb" ? kg * 2.20462 : kg;
}

function parseWeight(data?: DataView | null): number | null {
  if (!data || data.byteLength < 3) return null;
  const flags = data.getUint8(0);
  const imperial = (flags & 0x01) !== 0;
  const raw = data.getUint16(1, true);
  const kg = imperial ? raw * 0.45359237 * 0.01 : raw * 0.005;
  return Math.round(kg * 100) / 100;
}

/**
 * Parse the Bluetooth SIG "Body Composition Measurement" characteristic
 * (0x2A9C, part of service 0x181B). Field layout and resolutions are fixed
 * by the spec: a 16-bit flags word selects which optional fields follow
 * Body Fat Percentage (always present), in this exact order — Time Stamp,
 * User ID, Basal Metabolic Rate, Muscle Percentage, Muscle Mass, Fat Free
 * Mass, Soft Lean Mass, Body Water Mass, Impedance, Weight, Height.
 */
function parseBodyComposition(data?: DataView | null): Partial<Composition> | null {
  if (!data || data.byteLength < 4) return null;
  let offset = 0;
  const flags = data.getUint16(offset, true);
  offset += 2;
  const imperial = (flags & 0x0001) !== 0;
  const hasTimestamp = (flags & 0x0002) !== 0;
  const hasUserId = (flags & 0x0004) !== 0;
  const hasBmr = (flags & 0x0008) !== 0;
  const hasMusclePct = (flags & 0x0010) !== 0;
  const hasMuscleMass = (flags & 0x0020) !== 0;
  const hasFatFreeMass = (flags & 0x0040) !== 0;
  const hasSoftLeanMass = (flags & 0x0080) !== 0;
  const hasBodyWaterMass = (flags & 0x0100) !== 0;
  const hasImpedance = (flags & 0x0200) !== 0;
  const hasWeight = (flags & 0x0400) !== 0;

  if (data.byteLength < offset + 2) return null;
  const bodyFatPct = data.getUint16(offset, true) * 0.1;
  offset += 2;

  if (hasTimestamp) offset += 7;
  if (hasUserId) offset += 1;

  const result: Partial<Composition> = { bodyFatPct };
  // Mass fields share one resolution: 0.005 kg (SI) or 0.01 lb (imperial).
  const massToKg = (raw: number) => (imperial ? raw * 0.01 * 0.45359237 : raw * 0.005);

  if (hasBmr) {
    if (data.byteLength < offset + 2) return result;
    result.bmrKcal = Math.round(data.getUint16(offset, true) * 0.239006); // kJ -> kcal
    offset += 2;
  }
  if (hasMusclePct) {
    if (data.byteLength < offset + 2) return result;
    result.musclePct = data.getUint16(offset, true) * 0.1;
    offset += 2;
  }
  if (hasMuscleMass) {
    if (data.byteLength < offset + 2) return result;
    result.muscleMassKg = Math.round(massToKg(data.getUint16(offset, true)) * 10) / 10;
    offset += 2;
  }
  if (hasFatFreeMass) {
    if (data.byteLength < offset + 2) return result;
    result.fatFreeMassKg = Math.round(massToKg(data.getUint16(offset, true)) * 10) / 10;
    offset += 2;
  }
  if (hasSoftLeanMass) offset += 2; // not surfaced in the UI
  let bodyWaterMassKg: number | null = null;
  if (hasBodyWaterMass) {
    if (data.byteLength < offset + 2) return result;
    bodyWaterMassKg = massToKg(data.getUint16(offset, true));
    offset += 2;
  }
  if (hasImpedance) {
    if (data.byteLength < offset + 2) return result;
    result.impedanceOhm = data.getUint16(offset, true) * 0.1;
    offset += 2;
  }
  if (hasWeight) {
    if (data.byteLength < offset + 2) return result;
    result.valueKg = Math.round(massToKg(data.getUint16(offset, true)) * 100) / 100;
    offset += 2;
  }
  if (bodyWaterMassKg != null && result.valueKg != null && result.valueKg > 0) {
    result.waterPct = Math.round((bodyWaterMassKg / result.valueKg) * 1000) / 10;
  }
  return result;
}

type Bluetooth = {
  requestDevice: (opts: unknown) => Promise<{
    name?: string;
    gatt?: {
      connect: () => Promise<{
        getPrimaryService: (s: number) => Promise<{
          getCharacteristic: (c: number) => Promise<BluetoothRemoteGATTCharacteristic>;
        }>;
      }>;
    };
  }>;
};

type BluetoothRemoteGATTCharacteristic = EventTarget & {
  value?: DataView;
  startNotifications: () => Promise<unknown>;
};
