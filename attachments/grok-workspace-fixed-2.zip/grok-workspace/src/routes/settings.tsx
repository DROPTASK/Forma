import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { UserButton } from "@/lib/auth/gates";
import { Screen } from "@/components/shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTheme } from "@/components/theme";
import { getProfile, saveProfile } from "@/lib/server/fitness";
import { keys } from "@/lib/query";
import { toast } from "sonner";
import type { ThemePref, UnitPref } from "@/lib/types";
import { useState } from "react";

export const Route = createFileRoute("/settings")({ component: Settings });

function Settings() {
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: keys.profile, queryFn: () => getProfile() });
  const { pref, setPref } = useTheme();
  const [height, setHeight] = useState<string | null>(null);
  const [goalW, setGoalW] = useState<string | null>(null);
  const [cals, setCals] = useState<string | null>(null);
  const [birthYear, setBirthYear] = useState<string | null>(null);

  const save = useMutation({
    mutationFn: () =>
      saveProfile({
        data: {
          heightCm: height != null ? Number(height) : data?.heightCm,
          goalWeightKg: goalW != null ? Number(goalW) : data?.goalWeightKg,
          calorieGoal: cals != null ? Number(cals) : data?.calorieGoal,
          birthYear: birthYear != null ? Number(birthYear) : data?.birthYear,
        },
      }),
    onSuccess: () => {
      toast.success("Saved");
      void qc.invalidateQueries({ queryKey: keys.profile });
    },
  });

  const unitMut = useMutation({
    mutationFn: (unitPref: UnitPref) => saveProfile({ data: { unitPref } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: keys.profile }),
  });

  async function enableNotes() {
    if (!("Notification" in window)) {
      toast.error("Notifications are not available here");
      return;
    }
    const perm = await Notification.requestPermission();
    toast.message(perm === "granted" ? "Notifications on" : "Permission denied");
  }

  return (
    <Screen title="Settings">
      <Card className="mb-4">
        <UserButton />
      </Card>
      <Card className="mb-4 space-y-3">
        <p className="text-[13px] font-semibold text-muted">Appearance</p>
        <div className="flex gap-2">
          {(["system", "light", "dark"] as ThemePref[]).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => {
                setPref(t);
                void saveProfile({ data: { themePref: t } });
              }}
              className={`h-9 flex-1 rounded-full text-[13px] font-semibold capitalize ${
                pref === t ? "bg-accent text-accent-fg" : "bg-bg text-muted"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </Card>
      <Card className="mb-4 space-y-3">
        <p className="text-[13px] font-semibold text-muted">Units</p>
        <div className="flex gap-2">
          {(["kg", "lb"] as UnitPref[]).map((u) => (
            <button
              key={u}
              type="button"
              onClick={() => unitMut.mutate(u)}
              className={`h-9 flex-1 rounded-full text-[13px] font-semibold ${
                data?.unitPref === u ? "bg-accent text-accent-fg" : "bg-bg text-muted"
              }`}
            >
              {u}
            </button>
          ))}
        </div>
      </Card>
      <Card className="mb-4 space-y-3">
        <p className="text-[13px] font-semibold text-muted">Body & goals</p>
        <Input
          inputMode="decimal"
          value={height ?? String(data?.heightCm ?? "")}
          onChange={(e) => setHeight(e.target.value)}
          placeholder="Height (cm)"
        />
        <Input
          inputMode="numeric"
          value={birthYear ?? String(data?.birthYear ?? "")}
          onChange={(e) => setBirthYear(e.target.value)}
          placeholder="Birth year"
        />
        <div>
          <p className="mb-1 text-[12px] text-muted">
            Sex — used only to estimate body fat % when a scale gives weight but no bioimpedance reading
          </p>
          <div className="flex gap-2">
            {(["male", "female"] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => void saveProfile({ data: { sex: s } }).then(() => qc.invalidateQueries({ queryKey: keys.profile }))}
                className={`h-9 flex-1 rounded-full text-[13px] font-semibold capitalize ${
                  data?.sex === s ? "bg-accent text-accent-fg" : "bg-bg text-muted"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
        <Input
          inputMode="decimal"
          value={goalW ?? String(data?.goalWeightKg ?? "")}
          onChange={(e) => setGoalW(e.target.value)}
          placeholder="Goal weight (kg)"
        />
        <Input
          inputMode="numeric"
          value={cals ?? String(data?.calorieGoal ?? "")}
          onChange={(e) => setCals(e.target.value)}
          placeholder="Calorie goal"
        />
        <Button className="w-full" onClick={() => save.mutate()} disabled={save.isPending}>
          Save profile
        </Button>
      </Card>
      <Card className="mb-4 space-y-3">
        <p className="text-[13px] font-semibold text-muted">Notifications</p>
        <p className="text-[15px] text-muted">
          Local reminders for to-dos, meals, workouts, and streak-at-risk. Quiet hours can be set after
          permission is granted.
        </p>
        <Button variant="secondary" className="w-full" onClick={() => void enableNotes()}>
          Allow notifications
        </Button>
      </Card>
      <p className="text-[12px] leading-relaxed text-muted">
        Body photos stay on this device. Nutrition and measurements are estimates, not medical
        advice. Add Forma to your Android home screen from the browser menu for an app-like install.
      </p>
    </Screen>
  );
}
