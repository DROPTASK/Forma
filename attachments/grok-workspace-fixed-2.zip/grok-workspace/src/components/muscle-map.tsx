import { useState } from "react";
import { cn } from "@/lib/utils";

const GROUPS = [
  "chest",
  "shoulders",
  "biceps",
  "triceps",
  "abs",
  "obliques",
  "lats",
  "upper_back",
  "traps",
  "lower_back",
  "glutes",
  "quads",
  "hamstrings",
  "calves",
  "forearms",
] as const;

export function MuscleMapView({
  volume,
  onSelect,
}: {
  volume: Record<string, number>;
  onSelect: (muscle: string) => void;
}) {
  const [side, setSide] = useState<"front" | "back">("front");
  const max = Math.max(1, ...Object.values(volume));
  const fill = (g: string) => {
    const v = volume[g] ?? 0;
    const t = v / max;
    if (t <= 0) return "var(--app-separator)";
    return `color-mix(in srgb, var(--color-ring-move) ${Math.round(30 + t * 70)}%, var(--app-separator))`;
  };

  return (
    <div>
      <div className="mb-3 flex rounded-full bg-separator p-1">
        {(["front", "back"] as const).map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setSide(s)}
            className={cn(
              "h-9 flex-1 rounded-full text-[15px] font-semibold capitalize",
              side === s ? "bg-card text-fg" : "text-muted",
            )}
          >
            {s}
          </button>
        ))}
      </div>
      <svg viewBox="0 0 200 360" className="mx-auto block w-[260px]">
        {side === "front" ? <Front fill={fill} onSelect={onSelect} /> : <Back fill={fill} onSelect={onSelect} />}
      </svg>
      <div className="mt-3 flex justify-between text-[12px] text-muted">
        <span>Untrained</span>
        <span>High volume</span>
      </div>
    </div>
  );
}

function Front({ fill, onSelect }: { fill: (g: string) => string; onSelect: (g: string) => void }) {
  return (
    <g>
      <ellipse cx="100" cy="28" rx="16" ry="18" fill="var(--app-elevated)" />
      <path d="M70 52 C78 46 122 46 130 52 L138 78 L62 78 Z" fill={fill("shoulders")} onClick={() => onSelect("shoulders")} className="cursor-pointer" />
      <path d="M78 78 L122 78 L118 128 L82 128 Z" fill={fill("chest")} onClick={() => onSelect("chest")} className="cursor-pointer" />
      <path d="M84 128 L116 128 L112 168 L88 168 Z" fill={fill("abs")} onClick={() => onSelect("abs")} className="cursor-pointer" />
      <path d="M70 78 L82 128 L88 168 L74 168 L58 96 Z" fill={fill("obliques")} onClick={() => onSelect("obliques")} className="cursor-pointer" />
      <path d="M130 78 L118 128 L112 168 L126 168 L142 96 Z" fill={fill("obliques")} onClick={() => onSelect("obliques")} className="cursor-pointer" />
      <path d="M62 78 L52 132 L58 168 L74 150 L78 90 Z" fill={fill("biceps")} onClick={() => onSelect("biceps")} className="cursor-pointer" />
      <path d="M138 78 L148 132 L142 168 L126 150 L122 90 Z" fill={fill("biceps")} onClick={() => onSelect("biceps")} className="cursor-pointer" />
      <path d="M58 168 L54 214 L64 214 L74 168 Z" fill={fill("forearms")} onClick={() => onSelect("forearms")} className="cursor-pointer" />
      <path d="M142 168 L146 214 L136 214 L126 168 Z" fill={fill("forearms")} onClick={() => onSelect("forearms")} className="cursor-pointer" />
      <path d="M78 168 L99 168 L99 250 L72 250 Z" fill={fill("quads")} onClick={() => onSelect("quads")} className="cursor-pointer" />
      <path d="M101 168 L122 168 L128 250 L101 250 Z" fill={fill("quads")} onClick={() => onSelect("quads")} className="cursor-pointer" />
      <path d="M72 250 L78 330 L90 330 L99 250 Z" fill={fill("calves")} onClick={() => onSelect("calves")} className="cursor-pointer" />
      <path d="M101 250 L110 330 L122 330 L128 250 Z" fill={fill("calves")} onClick={() => onSelect("calves")} className="cursor-pointer" />
    </g>
  );
}

function Back({ fill, onSelect }: { fill: (g: string) => string; onSelect: (g: string) => void }) {
  return (
    <g>
      <ellipse cx="100" cy="28" rx="16" ry="18" fill="var(--app-elevated)" />
      <path d="M84 48 L116 48 L122 70 L78 70 Z" fill={fill("traps")} onClick={() => onSelect("traps")} className="cursor-pointer" />
      <path d="M70 52 C78 46 122 46 130 52 L138 78 L62 78 Z" fill={fill("shoulders")} onClick={() => onSelect("shoulders")} className="cursor-pointer" />
      <path d="M78 70 L122 70 L118 140 L82 140 Z" fill={fill("upper_back")} onClick={() => onSelect("upper_back")} className="cursor-pointer" />
      <path d="M62 78 L82 140 L78 168 L58 100 Z" fill={fill("lats")} onClick={() => onSelect("lats")} className="cursor-pointer" />
      <path d="M138 78 L118 140 L122 168 L142 100 Z" fill={fill("lats")} onClick={() => onSelect("lats")} className="cursor-pointer" />
      <path d="M82 140 L118 140 L114 178 L86 178 Z" fill={fill("lower_back")} onClick={() => onSelect("lower_back")} className="cursor-pointer" />
      <path d="M62 78 L50 140 L56 172 L74 150 L78 90 Z" fill={fill("triceps")} onClick={() => onSelect("triceps")} className="cursor-pointer" />
      <path d="M138 78 L150 140 L144 172 L126 150 L122 90 Z" fill={fill("triceps")} onClick={() => onSelect("triceps")} className="cursor-pointer" />
      <path d="M86 178 L114 178 L122 230 L78 230 Z" fill={fill("glutes")} onClick={() => onSelect("glutes")} className="cursor-pointer" />
      <path d="M78 230 L99 230 L99 300 L72 300 Z" fill={fill("hamstrings")} onClick={() => onSelect("hamstrings")} className="cursor-pointer" />
      <path d="M101 230 L122 230 L128 300 L101 300 Z" fill={fill("hamstrings")} onClick={() => onSelect("hamstrings")} className="cursor-pointer" />
      <path d="M72 300 L78 340 L90 340 L99 300 Z" fill={fill("calves")} onClick={() => onSelect("calves")} className="cursor-pointer" />
      <path d="M101 300 L110 340 L122 340 L128 300 Z" fill={fill("calves")} onClick={() => onSelect("calves")} className="cursor-pointer" />
    </g>
  );
}

export { GROUPS };
