/**
 * Body-composition helpers.
 *
 * Real bioimpedance metrics (muscle %, water %, fat-free mass, BMR,
 * impedance) come straight off a scale that implements the Bluetooth SIG
 * "Body Composition Service" (0x181B) — see the parsing in
 * `src/routes/scale.tsx`. Nothing in this file invents those numbers.
 *
 * The only thing computed locally is a classic anthropometric ESTIMATE for
 * scales (or manual entries) that only ever give a weight reading: BMI, and
 * the Deurenberg et al. (1991) body-fat-percentage formula that OpenScale
 * and most consumer fitness apps use as their "no impedance" fallback. These
 * are population-average approximations, not measurements — always surface
 * them in the UI labeled "Estimated".
 */

export type Sex = "male" | "female";

export function normalizeSex(sex: string | null | undefined): Sex {
  return sex === "female" ? "female" : "male";
}

export function bmi(weightKg: number | null | undefined, heightCm: number | null | undefined): number | null {
  if (!weightKg || !heightCm) return null;
  const m = heightCm / 100;
  return weightKg / (m * m);
}

export function bmiCategory(value: number): string {
  if (value < 18.5) return "Underweight";
  if (value < 25) return "Healthy range";
  if (value < 30) return "Overweight";
  return "Obesity range";
}

export function ageFromBirthYear(birthYear: number | null | undefined, now = new Date()): number | null {
  if (!birthYear) return null;
  const age = now.getFullYear() - birthYear;
  return age > 0 && age < 130 ? age : null;
}

/**
 * Deurenberg et al. 1991: BF% = 1.20 * BMI + 0.23 * age - 10.8 * sexFactor - 5.4
 * (sexFactor: male = 1, female = 0). Clamped to a sane physiological range.
 */
export function estimateBodyFatPct(params: {
  weightKg: number | null | undefined;
  heightCm: number | null | undefined;
  age: number | null | undefined;
  sex: Sex;
}): number | null {
  const b = bmi(params.weightKg, params.heightCm);
  if (b == null || !params.age) return null;
  const sexFactor = params.sex === "male" ? 1 : 0;
  const pct = 1.2 * b + 0.23 * params.age - 10.8 * sexFactor - 5.4;
  return Math.max(3, Math.min(60, Math.round(pct * 10) / 10));
}
