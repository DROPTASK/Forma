/**
 * OKOK / Chipsea "advertisement broadcast" scale protocol.
 *
 * A large family of cheap, unbranded ("Nameless") Bluetooth LE scales sold
 * under names like OKOK, Chipsea-BLE, Yoda, ADV, etc. don't expose a normal
 * GATT weight service at all. Instead they broadcast the current reading
 * directly inside the BLE *advertisement* packet's Manufacturer Specific
 * Data field, over and over, whether or not anything is connected. This is
 * exactly what openScale's `BluetoothOKOK` driver reads (see
 * https://github.com/oliexdev/openScale, drivers `OKOK C0` / `OKOK 1.1`) —
 * there is no GATT service to `connect()` to for these.
 *
 * Two sub-variants are handled here:
 *
 * 1. "C0" family (what the openScale UI labels "OKOK C0"). Reverse-engineered
 *    from real capture logs (github.com/oliexdev/openScale/issues/950,
 *    /issues/1177). The Web Bluetooth API parses the first two bytes of the
 *    manufacturer-specific-data field as a little-endian "company
 *    identifier" and hands back the rest as a DataView. For this family the
 *    low byte of that identifier is a fixed 0xC0 marker (the high byte
 *    varies packet to packet — these scales don't follow the Bluetooth SIG
 *    company-ID convention). Layout of the remaining bytes:
 *      [0-1] weight, big-endian, units of 0.01 kg
 *      [2-6] fixed per-model bytes
 *      [7]   varies (looks like a counter/stability flag, not a checksum)
 *      [8-13] the scale's own MAC address
 *
 * 2. "1.1" family (magic 0xCA, protocol version 0x11 — which Web Bluetooth
 *    also parses as a company identifier, 0x11CA, and this one *is* fixed).
 *    Layout (indices into the DataView, i.e. *after* the magic+version
 *    bytes), per github.com/oliexdev/openScale/pull/738:
 *      [3]  weight MSB
 *      [4]  weight LSB      (big-endian, units of 0.01 kg)
 *      [9]  body-composition properties byte (not decoded here)
 *      [16] checksum: XOR of the magic byte, version byte, and bytes [0-15]
 *      [last 6] the scale's own MAC address
 *
 * Neither family sends historical data or supports multiple user profiles —
 * you get exactly the number on the scale's own display, live, and nothing
 * else. There's also no reliable way to tell a "final settled" reading apart
 * from one still ticking up as someone steps on — callers should watch for a
 * few consecutive identical readings before treating one as final.
 */

export type OkokVariant = "c0" | "v1.1";

export type OkokReading = {
  valueKg: number;
  variant: OkokVariant;
  /** Only meaningful for the v1.1 family, where a checksum exists to check. */
  checksumOk?: boolean;
};

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/** Filters out garbage decodes — no consumer scale reads outside this range. */
function isPlausibleKg(kg: number): boolean {
  return Number.isFinite(kg) && kg > 0 && kg < 300;
}

/**
 * Attempt to decode one manufacturer-data entry from a BLE advertisement as
 * an OKOK/Chipsea broadcast reading. `companyId` and `data` are exactly what
 * a `BluetoothManufacturerDataMap` entry gives you (see `watchAdvertisement`
 * in scale-broadcast.ts). Returns null if this entry doesn't match either
 * known layout or the decoded weight isn't plausible.
 */
export function parseOkokManufacturerData(companyId: number, data: DataView): OkokReading | null {
  const lowByte = companyId & 0xff;

  if (lowByte === 0xc0) {
    if (data.byteLength < 2) return null;
    const raw = data.getUint16(0, false);
    const kg = raw / 100;
    if (!isPlausibleKg(kg)) return null;
    return { valueKg: round2(kg), variant: "c0" };
  }

  if (companyId === 0x11ca) {
    if (data.byteLength < 5) return null;
    const raw = (data.getUint8(3) << 8) | data.getUint8(4);
    const kg = raw / 100;
    if (!isPlausibleKg(kg)) return null;
    let checksumOk: boolean | undefined;
    if (data.byteLength > 16) {
      let x = 0xca ^ 0x11;
      for (let i = 0; i < 16; i++) x ^= data.getUint8(i);
      checksumOk = x === data.getUint8(16);
    }
    return { valueKg: round2(kg), variant: "v1.1", checksumOk };
  }

  return null;
}

/** Scan every manufacturer-data entry on an advertisement event for a reading. */
export function parseOkokAdvertisement(manufacturerData: Map<number, DataView> | undefined): OkokReading | null {
  if (!manufacturerData) return null;
  for (const [companyId, data] of manufacturerData) {
    const reading = parseOkokManufacturerData(companyId, data);
    if (reading) return reading;
  }
  return null;
}
