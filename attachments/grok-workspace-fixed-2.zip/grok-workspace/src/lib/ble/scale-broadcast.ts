/**
 * Thin wrapper around the experimental `navigator.bluetooth.requestLEScan`
 * API — the only way a web page can see raw BLE advertisement broadcasts
 * (as opposed to a normal GATT connection). This is what's needed for
 * OKOK/Chipsea-style scales; see `okok.ts` for why.
 *
 * Browser support (current as of writing): Chrome/Chromium only, and even
 * there it ships behind a flag — chrome://flags/#enable-experimental-web-platform-features
 * ("Experimental Web Platform features", must be Enabled) — most reliably
 * on Chrome for Android. It is not available in Safari or Firefox, and even
 * in Chrome on desktop the returned promise/events can silently never fire.
 * Always feature-detect with `isLeScanSupported()` before use and give
 * people a manual-entry fallback.
 */

export type BluetoothLeScanFilterInit = {
  services?: (string | number)[];
  name?: string;
  namePrefix?: string;
  manufacturerData?: { companyIdentifier: number; dataPrefix?: BufferSource; mask?: BufferSource }[];
};

export type BluetoothLeScanOptions = {
  filters?: BluetoothLeScanFilterInit[];
  acceptAllAdvertisements?: boolean;
  keepRepeatedDevices?: boolean;
};

export type BluetoothLeScan = {
  active: boolean;
  keepRepeatedDevices: boolean;
  acceptAllAdvertisements: boolean;
  stop: () => void;
};

export type BluetoothAdvertisingEvent = Event & {
  device: { id: string; name?: string };
  rssi?: number;
  txPower?: number;
  manufacturerData: Map<number, DataView>;
  serviceData: Map<string, DataView>;
  uuids: string[];
};

type ExperimentalBluetooth = EventTarget & {
  requestLEScan?: (options: BluetoothLeScanOptions) => Promise<BluetoothLeScan>;
};

function getBluetooth(): ExperimentalBluetooth | null {
  const bt = (navigator as Navigator & { bluetooth?: ExperimentalBluetooth }).bluetooth;
  return bt ?? null;
}

export function isWebBluetoothSupported(): boolean {
  return getBluetooth() != null;
}

export function isLeScanSupported(): boolean {
  const bt = getBluetooth();
  return !!bt && typeof bt.requestLEScan === "function";
}

/**
 * Start scanning for BLE advertisements. Calls `onAdvertisement` for every
 * packet seen while the scan is active (there is no built-in filtering by
 * manufacturer here — the OKOK company-ID byte varies per packet, see
 * okok.ts — so callers filter in the callback). Returns a stop function;
 * always call it when done (e.g. on unmount) to release the radio.
 */
export async function startAdvertisementScan(
  onAdvertisement: (ev: BluetoothAdvertisingEvent) => void,
): Promise<() => void> {
  const bt = getBluetooth();
  if (!bt || typeof bt.requestLEScan !== "function") {
    throw new Error(
      "This browser doesn't support scanning for Bluetooth broadcasts. " +
        "On Chrome for Android, turn on chrome://flags/#enable-experimental-web-platform-features " +
        "and restart the browser, or log the weight manually instead.",
    );
  }
  const listener = (ev: Event) => onAdvertisement(ev as BluetoothAdvertisingEvent);
  bt.addEventListener("advertisementreceived", listener);
  let scan: BluetoothLeScan;
  try {
    scan = await bt.requestLEScan({ acceptAllAdvertisements: true, keepRepeatedDevices: true });
  } catch (e) {
    bt.removeEventListener("advertisementreceived", listener);
    throw e;
  }
  return () => {
    bt.removeEventListener("advertisementreceived", listener);
    try {
      scan.stop();
    } catch {
      // Already stopped — fine.
    }
  };
}
