import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import type { Track } from "@/lib/types";
import { uid } from "@/lib/utils";

let cachedHost: { url: string; at: number } | null = null;

async function audiusHost(): Promise<string> {
  if (cachedHost && Date.now() - cachedHost.at < 10 * 60_000) return cachedHost.url;
  try {
    const res = await fetch("https://api.audius.co/v1/hosts", { signal: AbortSignal.timeout(4000) });
    if (res.ok) {
      const body = (await res.json()) as { data?: string[] };
      const host = body.data?.[0];
      if (host) {
        cachedHost = { url: host.replace(/\/$/, ""), at: Date.now() };
        return cachedHost.url;
      }
    }
  } catch {
    /* fall through */
  }
  cachedHost = { url: "https://discoveryprovider.audius.co", at: Date.now() };
  return cachedHost.url;
}

function mapTrack(t: Record<string, unknown>): Track {
  const user = (t.user as Record<string, unknown> | undefined) ?? {};
  const art = (t.artwork as Record<string, string> | undefined) ?? {};
  return {
    id: String(t.id ?? ""),
    title: String(t.title ?? "Untitled"),
    artistName: String(user.name ?? user.handle ?? "Unknown"),
    artworkUrl: art["480x480"] || art["150x150"] || null,
    durationSec: Number(t.duration ?? 0),
  };
}

export const searchTracks = createServerFn({ method: "POST" })
  .validator((d: { query: string }) => d)
  .handler(async ({ data }) => {
    const host = await audiusHost();
    const url = `${host}/v1/tracks/search?query=${encodeURIComponent(data.query)}&app_name=Forma`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return [] as Track[];
    const body = (await res.json()) as { data?: Record<string, unknown>[] };
    return (body.data ?? []).slice(0, 24).map(mapTrack);
  });

export const trendingTracks = createServerFn({ method: "POST" })
  .validator((d: { mood?: string }) => d)
  .handler(async ({ data }) => {
    const host = await audiusHost();
    const q = data.mood ? `genre=${encodeURIComponent(data.mood)}&` : "";
    const url = `${host}/v1/tracks/trending?${q}app_name=Forma`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return [] as Track[];
    const body = (await res.json()) as { data?: Record<string, unknown>[] };
    return (body.data ?? []).slice(0, 24).map(mapTrack);
  });

export const resolveStream = createServerFn({ method: "POST" })
  .validator((d: { id: string }) => d)
  .handler(async ({ data }) => {
    const host = await audiusHost();
    const url = `${host}/v1/tracks/${encodeURIComponent(data.id)}/stream?app_name=Forma`;
    return { url };
  });

export const listPlaylists = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql`select * from playlists where user_id = ${context.userId} order by created_at desc`;
    return rows.map((r) => ({
      id: String(r.id),
      name: String(r.name),
      isWorkout: r.is_workout === true,
      tracks: (typeof r.tracks_json === "string" ? JSON.parse(String(r.tracks_json)) : r.tracks_json) as Track[],
    }));
  });

export const savePlaylist = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { name: string; tracks: Track[]; isWorkout?: boolean }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = uid();
    await sql.query(
      `insert into playlists (id, user_id, name, is_workout, tracks_json) values ($1,$2,$3,$4,$5::jsonb)`,
      [id, context.userId, data.name, data.isWorkout ?? false, JSON.stringify(data.tracks)],
    );
    return { id };
  });
