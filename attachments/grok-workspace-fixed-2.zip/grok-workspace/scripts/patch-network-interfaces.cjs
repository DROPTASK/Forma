"use strict";
/**
 * Some sandboxed containers (also seen on Android/Termux) block the syscall
 * `os.networkInterfaces()` needs (SIOCGIFCONF / netlink), so Node throws
 * `SystemError [ERR_SYSTEM_ERROR]: uv_interface_addresses returned Unknown
 * system error 13/97/…` instead of returning a result.
 *
 * Vite calls `os.networkInterfaces()` while composing the "Network:
 * http://…" line it prints whenever the dev server binds a wildcard host
 * (`--host 0.0.0.0`, which this workspace always uses). This Vite version
 * doesn't catch that failure, so on a host where the syscall is blocked the
 * whole `vite dev` process crashes before it ever starts listening — even
 * though nothing about compiling or serving the app actually needs it.
 *
 * Loaded via `NODE_OPTIONS=--require` (see `with-app-env.mjs`) before any
 * other module — including Vite — gets a reference to `os.networkInterfaces`,
 * so every caller in the process observes the patched version. On a host
 * where the syscall works fine this is a no-op passthrough.
 */
const os = require("node:os");
const original = os.networkInterfaces;

os.networkInterfaces = function networkInterfacesSafe(...args) {
  try {
    return original.apply(this, args);
  } catch (err) {
    if (err && err.code === "ERR_SYSTEM_ERROR") return {};
    throw err;
  }
};
