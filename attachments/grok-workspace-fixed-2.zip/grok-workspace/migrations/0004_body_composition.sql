-- Body-composition fields for weight_entries, populated either straight off a
-- Bluetooth SIG "Body Composition Service" (0x181B) scale, or as a labeled
-- anthropometric estimate when only a weight reading is available.
alter table weight_entries add column if not exists muscle_pct double precision;
alter table weight_entries add column if not exists muscle_mass_kg double precision;
alter table weight_entries add column if not exists fat_free_mass_kg double precision;
alter table weight_entries add column if not exists water_pct double precision;
alter table weight_entries add column if not exists bmr_kcal double precision;
alter table weight_entries add column if not exists impedance_ohm double precision;
alter table weight_entries add column if not exists is_estimated boolean not null default false;
